export { default as IbCurveMainPage } from './IbCurveMainPage';
